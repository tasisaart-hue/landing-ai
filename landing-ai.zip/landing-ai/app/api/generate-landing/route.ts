import { NextRequest, NextResponse } from "next/server";
import { getServiceSupabase } from "@/lib/supabase";

/**
 * Recebe os dados básicos do formulário inicial (nome, Instagram, WhatsApp, endereço),
 * opcionalmente busca fotos via /api/instagram, gera o copy com a API da Anthropic
 * e cria o registro do cliente + landing page no Supabase.
 */

const SYSTEM_PROMPT = `Você é um copywriter especialista em landing pages de alta conversão.
Escreva SEMPRE em português do Brasil, tom profissional e acolhedor, sem exageros nem clichês genéricos.
Responda APENAS com um JSON válido, sem markdown, sem texto adicional, no formato:
{
  "hero_title": string (máx 8 palavras, impactante),
  "hero_subtitle": string (1 frase, reforça o valor),
  "about_text": string (2-3 parágrafos curtos sobre a empresa),
  "cta_text": string (chamada para ação curta, ex: "Agende seu horário"),
  "services": [{ "name": string, "description": string (1 frase), "duration_minutes": number }]
}`;

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { company_name, instagram_url, whatsapp, address, instagram_username, business_niche } = body;

  if (!company_name || !whatsapp) {
    return NextResponse.json({ error: "Nome da empresa e WhatsApp são obrigatórios." }, { status: 400 });
  }

  const userPrompt = `Empresa: ${company_name}
Instagram: ${instagram_url ?? "não informado"}
Segmento/observações: ${business_niche ?? "não informado"}
Endereço: ${address ?? "não informado"}

Gere o conteúdo da landing page desta empresa seguindo o formato JSON pedido. Sugira de 3 a 6 serviços plausíveis para esse tipo de negócio.`;

  let generated;
  try {
    const aiRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY ?? "",
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1200,
        system: SYSTEM_PROMPT,
        messages: [{ role: "user", content: userPrompt }],
      }),
    });

    const aiData = await aiRes.json();
    const text = aiData?.content?.find((c: any) => c.type === "text")?.text ?? "{}";
    generated = JSON.parse(text.replace(/```json|```/g, "").trim());
  } catch (err) {
    return NextResponse.json({ error: "Falha ao gerar conteúdo com IA." }, { status: 500 });
  }

  // Tenta buscar fotos do Instagram, se um token já estiver disponível (fluxo avançado).
  // No fluxo simples, o admin faz upload manual das fotos depois.
  const galleryImages: string[] = [];

  const slug = slugify(company_name);

  const db = getServiceSupabase();
  const { data: client, error } = await db
    .from("clients")
    .insert({
      slug,
      company_name,
      instagram_url,
      instagram_username,
      whatsapp,
      address,
      hero_title: generated.hero_title,
      hero_subtitle: generated.hero_subtitle,
      about_text: generated.about_text,
      cta_text: generated.cta_text,
      services: (generated.services ?? []).map((s: any, i: number) => ({
        id: `svc_${i}_${Date.now()}`,
        ...s,
      })),
      gallery_images: galleryImages,
      is_published: false,
    })
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: "Não foi possível salvar a landing page." }, { status: 500 });
  }

  return NextResponse.json({ client }, { status: 201 });
}

function slugify(text: string): string {
  const base = text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
  return `${base}-${Math.random().toString(36).slice(2, 6)}`;
}
