import { NextRequest, NextResponse } from "next/server";
import { getServiceSupabase } from "@/lib/supabase";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { client_id, service_name, booking_date, booking_time, customer_name, customer_phone } = body;

  if (!client_id || !service_name || !booking_date || !booking_time || !customer_name || !customer_phone) {
    return NextResponse.json({ error: "Campos obrigatórios ausentes." }, { status: 400 });
  }

  const db = getServiceSupabase();

  // Confere se o horário ainda está livre (evita corrida entre dois usuários)
  const { data: conflict } = await db
    .from("bookings")
    .select("id")
    .eq("client_id", client_id)
    .eq("booking_date", booking_date)
    .eq("booking_time", booking_time)
    .in("status", ["pending", "confirmed"])
    .maybeSingle();

  if (conflict) {
    return NextResponse.json({ error: "Esse horário acabou de ser reservado. Escolha outro." }, { status: 409 });
  }

  const { data, error } = await db
    .from("bookings")
    .insert({
      client_id,
      service_name,
      booking_date,
      booking_time,
      customer_name,
      customer_phone,
      status: "pending",
    })
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: "Não foi possível criar o agendamento." }, { status: 500 });
  }

  return NextResponse.json({ booking: data }, { status: 201 });
}
