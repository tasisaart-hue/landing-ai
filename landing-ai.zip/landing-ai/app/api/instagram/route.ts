import { NextRequest, NextResponse } from "next/server";

/**
 * IMPORTANTE:
 * O Instagram não permite raspagem (scraping) de perfis públicos — isso viola
 * os Termos de Uso da Meta e pode gerar bloqueio de IP/conta.
 *
 * A forma correta e suportada é usar a Instagram Graph API, que exige:
 *  1. Uma conta Instagram Business ou Creator
 *  2. Vinculação a uma Página do Facebook
 *  3. Um App no Meta for Developers com permissão `instagram_basic`
 *  4. Um token de acesso de longa duração do usuário/página
 *
 * Este endpoint recebe esse token (salvo no cadastro do cliente) e retorna
 * as últimas fotos públicas da conta para popular a galeria.
 *
 * Caso o cliente não tenha/queira conectar a Graph API, o admin pode
 * simplesmente fazer upload manual das fotos no painel administrativo
 * (ver /app/admin) — a galeria funciona normalmente com URLs de imagem.
 */

const GRAPH_API_VERSION = "v20.0";

export async function POST(req: NextRequest) {
  const { instagram_user_id, access_token, limit = 12 } = await req.json();

  if (!instagram_user_id || !access_token) {
    return NextResponse.json(
      {
        error:
          "instagram_user_id e access_token são obrigatórios. Sem eles, use o upload manual de fotos no painel admin.",
      },
      { status: 400 }
    );
  }

  try {
    const fields = "id,caption,media_type,media_url,thumbnail_url,permalink,timestamp";
    const url = `https://graph.facebook.com/${GRAPH_API_VERSION}/${instagram_user_id}/media?fields=${fields}&limit=${limit}&access_token=${access_token}`;

    const res = await fetch(url);
    const data = await res.json();

    if (data.error) {
      return NextResponse.json({ error: data.error.message ?? "Erro ao consultar a Graph API." }, { status: 400 });
    }

    const images: string[] = (data.data ?? [])
      .filter((item: any) => item.media_type === "IMAGE" || item.media_type === "CAROUSEL_ALBUM")
      .map((item: any) => item.media_url)
      .filter(Boolean);

    return NextResponse.json({ images });
  } catch (err) {
    return NextResponse.json({ error: "Falha ao conectar com o Instagram." }, { status: 500 });
  }
}
