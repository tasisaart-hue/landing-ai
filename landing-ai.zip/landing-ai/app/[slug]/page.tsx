import { notFound } from "next/navigation";
import { getServiceSupabase } from "@/lib/supabase";
import { Client } from "@/lib/types";
import Hero from "@/components/Hero";
import Gallery from "@/components/Gallery";
import Services from "@/components/Services";
import About from "@/components/About";
import Testimonials from "@/components/Testimonials";
import LocationMap from "@/components/LocationMap";
import BookingForm from "@/components/BookingForm";
import WhatsAppButton from "@/components/WhatsAppButton";
import Footer from "@/components/Footer";

async function getClient(slug: string): Promise<Client | null> {
  const db = getServiceSupabase();
  const { data } = await db.from("clients").select("*").eq("slug", slug).eq("is_published", true).maybeSingle();
  return data as Client | null;
}

export default async function LandingPage({ params }: { params: { slug: string } }) {
  const client = await getClient(params.slug);
  if (!client) notFound();

  const whatsappDigits = client.whatsapp.replace(/\D/g, "");
  const whatsappLink = `https://wa.me/${whatsappDigits}`;

  return (
    <div
      style={{ ["--brand-color" as any]: client.brand_color } as React.CSSProperties}
      className="bg-surface"
    >
      <Hero
        title={client.hero_title ?? client.company_name}
        subtitle={client.hero_subtitle ?? ""}
        ctaText={client.cta_text}
        whatsappLink={whatsappLink}
        brandColor={client.brand_color}
        backgroundImage={client.gallery_images?.[0]}
      />

      <Gallery images={client.gallery_images ?? []} />

      <Services services={client.services ?? []} />

      <About
        companyName={client.company_name}
        text={client.about_text ?? ""}
        image={client.gallery_images?.[1]}
      />

      <Testimonials testimonials={client.testimonials ?? []} />

      <BookingForm clientId={client.id} services={client.services ?? []} />

      <LocationMap address={client.address} />

      <Footer companyName={client.company_name} />

      <WhatsAppButton phone={client.whatsapp} />
    </div>
  );
}
