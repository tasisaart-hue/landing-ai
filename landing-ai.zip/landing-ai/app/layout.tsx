import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Landing AI",
  description: "Gere landing pages modernas automaticamente a partir do Instagram do seu negócio.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="bg-surface font-sans antialiased">{children}</body>
    </html>
  );
}
