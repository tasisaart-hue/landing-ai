"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { Client, AvailabilitySlot, Booking, Service } from "@/lib/types";
import {
  Image as ImageIcon,
  FileText,
  Wrench,
  Clock,
  CalendarCheck,
  LogOut,
  Plus,
  Trash2,
  ExternalLink,
} from "lucide-react";

type Tab = "fotos" | "textos" | "servicos" | "horarios" | "agendamentos";

const WEEKDAYS = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];

export default function AdminPage() {
  const router = useRouter();
  const [client, setClient] = useState<Client | null>(null);
  const [slots, setSlots] = useState<AvailabilitySlot[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [tab, setTab] = useState<Tab>("fotos");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    async function load() {
      const { data: session } = await supabase.auth.getSession();
      if (!session.session) {
        router.push("/admin/login");
        return;
      }

      const { data: adminUser } = await supabase
        .from("admin_users")
        .select("client_id")
        .eq("id", session.session.user.id)
        .maybeSingle();

      if (!adminUser?.client_id) {
        setLoading(false);
        return;
      }

      const [{ data: clientData }, { data: slotsData }, { data: bookingsData }] = await Promise.all([
        supabase.from("clients").select("*").eq("id", adminUser.client_id).single(),
        supabase.from("availability_slots").select("*").eq("client_id", adminUser.client_id).order("weekday"),
        supabase
          .from("bookings")
          .select("*")
          .eq("client_id", adminUser.client_id)
          .order("booking_date", { ascending: true }),
      ]);

      setClient(clientData as Client);
      setSlots((slotsData ?? []) as AvailabilitySlot[]);
      setBookings((bookingsData ?? []) as Booking[]);
      setLoading(false);
    }
    load();
  }, [router]);

  async function saveClient(patch: Partial<Client>) {
    if (!client) return;
    setSaving(true);
    const { error } = await supabase.from("clients").update(patch).eq("id", client.id);
    if (!error) setClient({ ...client, ...patch });
    setSaving(false);
  }

  async function togglePublish() {
    if (!client) return;
    await saveClient({ is_published: !client.is_published });
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push("/admin/login");
  }

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center bg-surface text-white/60">Carregando...</div>;
  }

  if (!client) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-surface text-white/60">
        <p>Nenhuma landing page vinculada a este usuário admin.</p>
        <p className="text-sm">Cadastre este usuário em `admin_users` vinculado ao `client_id` correto.</p>
      </div>
    );
  }

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "fotos", label: "Fotos", icon: <ImageIcon size={16} /> },
    { id: "textos", label: "Textos", icon: <FileText size={16} /> },
    { id: "servicos", label: "Serviços", icon: <Wrench size={16} /> },
    { id: "horarios", label: "Horários", icon: <Clock size={16} /> },
    { id: "agendamentos", label: "Agendamentos", icon: <CalendarCheck size={16} /> },
  ];

  return (
    <div className="min-h-screen bg-surface text-white">
      {/* Topbar */}
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-6 py-4">
        <div>
          <h1 className="font-display text-lg font-bold">{client.company_name}</h1>
          <a
            href={`/${client.slug}`}
            target="_blank"
            className="flex items-center gap-1 text-xs text-white/50 hover:text-brand"
          >
            /{client.slug} <ExternalLink size={12} />
          </a>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={togglePublish}
            className={`rounded-full px-4 py-2 text-xs font-semibold transition ${
              client.is_published ? "bg-emerald-500/20 text-emerald-400" : "bg-white/10 text-white/60"
            }`}
          >
            {client.is_published ? "Publicada" : "Rascunho"} — clique para {client.is_published ? "despublicar" : "publicar"}
          </button>
          <button onClick={handleLogout} className="flex items-center gap-1 text-sm text-white/50 hover:text-white">
            <LogOut size={16} /> Sair
          </button>
        </div>
      </header>

      <div className="flex flex-col gap-6 p-6 md:flex-row">
        {/* Tabs */}
        <nav className="flex gap-2 overflow-x-auto md:w-56 md:flex-col">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-medium transition ${
                tab === t.id ? "bg-brand/20 text-brand" : "text-white/60 hover:bg-white/5"
              }`}
            >
              {t.icon} {t.label}
            </button>
          ))}
        </nav>

        <main className="flex-1">
          {tab === "fotos" && <PhotosTab client={client} onSave={saveClient} saving={saving} />}
          {tab === "textos" && <TextsTab client={client} onSave={saveClient} saving={saving} />}
          {tab === "servicos" && <ServicesTab client={client} onSave={saveClient} saving={saving} />}
          {tab === "horarios" && <HoursTab clientId={client.id} slots={slots} setSlots={setSlots} />}
          {tab === "agendamentos" && <BookingsTab bookings={bookings} setBookings={setBookings} />}
        </main>
      </div>
    </div>
  );
}

// ---------------- FOTOS ----------------
function PhotosTab({
  client,
  onSave,
  saving,
}: {
  client: Client;
  onSave: (p: Partial<Client>) => void;
  saving: boolean;
}) {
  const [images, setImages] = useState<string[]>(client.gallery_images ?? []);
  const [newUrl, setNewUrl] = useState("");

  function addImage() {
    if (!newUrl.trim()) return;
    const updated = [...images, newUrl.trim()];
    setImages(updated);
    setNewUrl("");
    onSave({ gallery_images: updated });
  }

  function removeImage(idx: number) {
    const updated = images.filter((_, i) => i !== idx);
    setImages(updated);
    onSave({ gallery_images: updated });
  }

  return (
    <Card title="Fotos da galeria" subtitle="Cole URLs de imagens (upload de arquivos pode ser feito via Supabase Storage).">
      <div className="mb-4 flex gap-2">
        <input
          value={newUrl}
          onChange={(e) => setNewUrl(e.target.value)}
          placeholder="https://.../foto.jpg"
          className="flex-1 rounded-xl border border-white/10 bg-surface px-4 py-2.5 text-sm outline-none focus:border-brand"
        />
        <button onClick={addImage} className="flex items-center gap-1 rounded-xl bg-brand px-4 py-2.5 text-sm font-semibold">
          <Plus size={16} /> Adicionar
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {images.map((url, i) => (
          <div key={i} className="group relative aspect-square overflow-hidden rounded-xl border border-white/10">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={url} alt="" className="h-full w-full object-cover" />
            <button
              onClick={() => removeImage(i)}
              className="absolute right-1.5 top-1.5 rounded-full bg-black/60 p-1.5 opacity-0 transition group-hover:opacity-100"
            >
              <Trash2 size={14} />
            </button>
          </div>
        ))}
      </div>
      {saving && <p className="mt-3 text-xs text-white/40">Salvando...</p>}
    </Card>
  );
}

// ---------------- TEXTOS ----------------
function TextsTab({
  client,
  onSave,
  saving,
}: {
  client: Client;
  onSave: (p: Partial<Client>) => void;
  saving: boolean;
}) {
  const [form, setForm] = useState({
    hero_title: client.hero_title ?? "",
    hero_subtitle: client.hero_subtitle ?? "",
    about_text: client.about_text ?? "",
    cta_text: client.cta_text ?? "",
  });

  function handleBlurSave() {
    onSave(form);
  }

  return (
    <Card title="Textos da landing page" subtitle="Editados automaticamente pela IA — ajuste como preferir.">
      <div className="space-y-4">
        <LabeledInput
          label="Título principal (Hero)"
          value={form.hero_title}
          onChange={(v) => setForm((f) => ({ ...f, hero_title: v }))}
          onBlur={handleBlurSave}
        />
        <LabeledInput
          label="Subtítulo"
          value={form.hero_subtitle}
          onChange={(v) => setForm((f) => ({ ...f, hero_subtitle: v }))}
          onBlur={handleBlurSave}
        />
        <LabeledTextarea
          label="Sobre a empresa"
          value={form.about_text}
          onChange={(v) => setForm((f) => ({ ...f, about_text: v }))}
          onBlur={handleBlurSave}
        />
        <LabeledInput
          label="Texto do botão (CTA)"
          value={form.cta_text}
          onChange={(v) => setForm((f) => ({ ...f, cta_text: v }))}
          onBlur={handleBlurSave}
        />
      </div>
      {saving && <p className="mt-3 text-xs text-white/40">Salvando...</p>}
    </Card>
  );
}

// ---------------- SERVIÇOS ----------------
function ServicesTab({
  client,
  onSave,
  saving,
}: {
  client: Client;
  onSave: (p: Partial<Client>) => void;
  saving: boolean;
}) {
  const [services, setServices] = useState<Service[]>(client.services ?? []);

  function updateService(idx: number, patch: Partial<Service>) {
    const updated = services.map((s, i) => (i === idx ? { ...s, ...patch } : s));
    setServices(updated);
  }

  function addService() {
    const updated = [
      ...services,
      { id: `svc_${Date.now()}`, name: "Novo serviço", description: "", duration_minutes: 30 },
    ];
    setServices(updated);
    onSave({ services: updated });
  }

  function removeService(idx: number) {
    const updated = services.filter((_, i) => i !== idx);
    setServices(updated);
    onSave({ services: updated });
  }

  return (
    <Card title="Serviços" subtitle="Aparecem na seção de serviços e no formulário de agendamento.">
      <div className="space-y-4">
        {services.map((s, i) => (
          <div key={s.id} className="rounded-xl border border-white/10 p-4">
            <div className="mb-2 flex items-center justify-between">
              <input
                value={s.name}
                onChange={(e) => updateService(i, { name: e.target.value })}
                onBlur={() => onSave({ services })}
                className="w-full rounded-lg border border-white/10 bg-surface px-3 py-2 text-sm font-semibold outline-none focus:border-brand"
              />
              <button onClick={() => removeService(i)} className="ml-2 text-white/40 hover:text-red-400">
                <Trash2 size={16} />
              </button>
            </div>
            <textarea
              value={s.description}
              onChange={(e) => updateService(i, { description: e.target.value })}
              onBlur={() => onSave({ services })}
              rows={2}
              className="mb-2 w-full rounded-lg border border-white/10 bg-surface px-3 py-2 text-sm outline-none focus:border-brand"
              placeholder="Descrição curta"
            />
            <div className="flex gap-3">
              <input
                value={s.price ?? ""}
                onChange={(e) => updateService(i, { price: e.target.value })}
                onBlur={() => onSave({ services })}
                placeholder="Preço (opcional)"
                className="w-1/2 rounded-lg border border-white/10 bg-surface px-3 py-2 text-sm outline-none focus:border-brand"
              />
              <input
                type="number"
                value={s.duration_minutes}
                onChange={(e) => updateService(i, { duration_minutes: Number(e.target.value) })}
                onBlur={() => onSave({ services })}
                placeholder="Duração (min)"
                className="w-1/2 rounded-lg border border-white/10 bg-surface px-3 py-2 text-sm outline-none focus:border-brand"
              />
            </div>
          </div>
        ))}

        <button
          onClick={addService}
          className="flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-white/20 py-3 text-sm text-white/60 hover:border-brand hover:text-brand"
        >
          <Plus size={16} /> Adicionar serviço
        </button>
      </div>
      {saving && <p className="mt-3 text-xs text-white/40">Salvando...</p>}
    </Card>
  );
}

// ---------------- HORÁRIOS ----------------
function HoursTab({
  clientId,
  slots,
  setSlots,
}: {
  clientId: string;
  slots: AvailabilitySlot[];
  setSlots: (s: AvailabilitySlot[]) => void;
}) {
  const [form, setForm] = useState({ weekday: 1, start_time: "09:00", end_time: "18:00", slot_duration_minutes: 30 });

  async function addSlot() {
    const { data, error } = await supabase
      .from("availability_slots")
      .insert({ client_id: clientId, ...form, active: true })
      .select()
      .single();
    if (!error && data) setSlots([...slots, data as AvailabilitySlot]);
  }

  async function removeSlot(id: string) {
    await supabase.from("availability_slots").delete().eq("id", id);
    setSlots(slots.filter((s) => s.id !== id));
  }

  return (
    <Card title="Horários disponíveis" subtitle="Configure os dias e faixas de horário em que os clientes podem agendar.">
      <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <select
          value={form.weekday}
          onChange={(e) => setForm((f) => ({ ...f, weekday: Number(e.target.value) }))}
          className="rounded-lg border border-white/10 bg-surface px-3 py-2 text-sm"
        >
          {WEEKDAYS.map((d, i) => (
            <option key={i} value={i}>
              {d}
            </option>
          ))}
        </select>
        <input
          type="time"
          value={form.start_time}
          onChange={(e) => setForm((f) => ({ ...f, start_time: e.target.value }))}
          className="rounded-lg border border-white/10 bg-surface px-3 py-2 text-sm"
        />
        <input
          type="time"
          value={form.end_time}
          onChange={(e) => setForm((f) => ({ ...f, end_time: e.target.value }))}
          className="rounded-lg border border-white/10 bg-surface px-3 py-2 text-sm"
        />
        <input
          type="number"
          value={form.slot_duration_minutes}
          onChange={(e) => setForm((f) => ({ ...f, slot_duration_minutes: Number(e.target.value) }))}
          placeholder="Duração (min)"
          className="rounded-lg border border-white/10 bg-surface px-3 py-2 text-sm"
        />
      </div>
      <button onClick={addSlot} className="mb-6 flex items-center gap-2 rounded-xl bg-brand px-4 py-2.5 text-sm font-semibold">
        <Plus size={16} /> Adicionar faixa de horário
      </button>

      <div className="space-y-2">
        {slots.map((s) => (
          <div key={s.id} className="flex items-center justify-between rounded-xl border border-white/10 px-4 py-3 text-sm">
            <span>
              {WEEKDAYS[s.weekday]} · {s.start_time.slice(0, 5)} às {s.end_time.slice(0, 5)} · a cada{" "}
              {s.slot_duration_minutes} min
            </span>
            <button onClick={() => removeSlot(s.id)} className="text-white/40 hover:text-red-400">
              <Trash2 size={16} />
            </button>
          </div>
        ))}
      </div>
    </Card>
  );
}

// ---------------- AGENDAMENTOS ----------------
function BookingsTab({
  bookings,
  setBookings,
}: {
  bookings: Booking[];
  setBookings: (b: Booking[]) => void;
}) {
  async function updateStatus(id: string, status: Booking["status"]) {
    await supabase.from("bookings").update({ status }).eq("id", id);
    setBookings(bookings.map((b) => (b.id === id ? { ...b, status } : b)));
  }

  return (
    <Card title="Agendamentos" subtitle="Confirme, cancele ou marque como concluído.">
      <div className="space-y-2">
        {bookings.length === 0 && <p className="text-sm text-white/50">Nenhum agendamento ainda.</p>}
        {bookings.map((b) => (
          <div key={b.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/10 px-4 py-3 text-sm">
            <div>
              <p className="font-semibold">
                {b.customer_name} · {b.service_name}
              </p>
              <p className="text-white/50">
                {b.booking_date} às {b.booking_time.slice(0, 5)} · {b.customer_phone}
              </p>
            </div>
            <select
              value={b.status}
              onChange={(e) => updateStatus(b.id, e.target.value as Booking["status"])}
              className="rounded-lg border border-white/10 bg-surface px-3 py-1.5 text-xs"
            >
              <option value="pending">Pendente</option>
              <option value="confirmed">Confirmado</option>
              <option value="cancelled">Cancelado</option>
              <option value="done">Concluído</option>
            </select>
          </div>
        ))}
      </div>
    </Card>
  );
}

// ---------------- UI helpers ----------------
function Card({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
      <h2 className="text-lg font-semibold">{title}</h2>
      {subtitle && <p className="mb-5 mt-1 text-sm text-white/50">{subtitle}</p>}
      <div className={subtitle ? "" : "mt-5"}>{children}</div>
    </div>
  );
}

function LabeledInput({
  label,
  value,
  onChange,
  onBlur,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  onBlur: () => void;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium text-white/70">{label}</label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onBlur={onBlur}
        className="w-full rounded-xl border border-white/10 bg-surface px-4 py-2.5 text-sm outline-none focus:border-brand"
      />
    </div>
  );
}

function LabeledTextarea({
  label,
  value,
  onChange,
  onBlur,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  onBlur: () => void;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium text-white/70">{label}</label>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onBlur={onBlur}
        rows={5}
        className="w-full rounded-xl border border-white/10 bg-surface px-4 py-2.5 text-sm outline-none focus:border-brand"
      />
    </div>
  );
}
