"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import { fadeInUp } from "@/lib/animations";
import { Sparkles, Instagram, Phone, MapPin } from "lucide-react";

export default function HomePage() {
  const router = useRouter();
  const [form, setForm] = useState({
    company_name: "",
    instagram_url: "",
    whatsapp: "",
    address: "",
    business_niche: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function update<K extends keyof typeof form>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const res = await fetch("/api/generate-landing", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });

    setLoading(false);

    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      setError(body?.error ?? "Não foi possível gerar a landing page.");
      return;
    }

    const { client } = await res.json();
    router.push(`/admin?client=${client.slug}&created=1`);
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-surface px-6 py-16 text-white">
      <motion.div
        variants={fadeInUp}
        initial="hidden"
        animate="visible"
        className="w-full max-w-lg rounded-3xl border border-white/10 bg-white/5 p-8 sm:p-10"
      >
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-brand/20 text-brand">
            <Sparkles size={26} />
          </div>
          <h1 className="font-display text-2xl font-bold">Landing AI</h1>
          <p className="mt-2 text-sm text-white/60">
            Informe os dados do seu negócio e a IA cria sua landing page automaticamente.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="Nome da empresa" required>
            <input
              required
              value={form.company_name}
              onChange={(e) => update("company_name", e.target.value)}
              className="input"
              placeholder="Ex: Studio Bella Estética"
            />
          </Field>

          <Field label="Instagram" icon={<Instagram size={16} />}>
            <input
              value={form.instagram_url}
              onChange={(e) => update("instagram_url", e.target.value)}
              className="input"
              placeholder="https://instagram.com/seunegocio"
            />
          </Field>

          <Field label="WhatsApp" required icon={<Phone size={16} />}>
            <input
              required
              value={form.whatsapp}
              onChange={(e) => update("whatsapp", e.target.value)}
              className="input"
              placeholder="5511999999999"
            />
          </Field>

          <Field label="Endereço (opcional)" icon={<MapPin size={16} />}>
            <input
              value={form.address}
              onChange={(e) => update("address", e.target.value)}
              className="input"
              placeholder="Rua Exemplo, 123 - Bairro, Cidade"
            />
          </Field>

          <Field label="Segmento do negócio (ajuda a IA a escrever melhor)">
            <input
              value={form.business_niche}
              onChange={(e) => update("business_niche", e.target.value)}
              className="input"
              placeholder="Ex: salão de beleza, barbearia, clínica odontológica..."
            />
          </Field>

          {error && <p className="text-sm text-red-400">{error}</p>}

          <motion.button
            type="submit"
            disabled={loading}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full rounded-xl bg-brand py-4 font-semibold text-white transition disabled:opacity-50"
          >
            {loading ? "Gerando landing page..." : "Gerar landing page"}
          </motion.button>
        </form>
      </motion.div>
    </main>
  );
}

function Field({
  label,
  children,
  required,
  icon,
}: {
  label: string;
  children: React.ReactNode;
  required?: boolean;
  icon?: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-white/80">
        {icon}
        {label} {required && <span className="text-brand">*</span>}
      </label>
      {children}
      <style jsx global>{`
        .input {
          width: 100%;
          border-radius: 0.75rem;
          border: 1px solid rgba(255, 255, 255, 0.1);
          background: #0b0b0f;
          padding: 0.75rem 1rem;
          font-size: 0.875rem;
          color: white;
          outline: none;
        }
        .input:focus {
          border-color: var(--brand-color, #6366f1);
        }
        .input::placeholder {
          color: rgba(255, 255, 255, 0.3);
        }
      `}</style>
    </div>
  );
}
