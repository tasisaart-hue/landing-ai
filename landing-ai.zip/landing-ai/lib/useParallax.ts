"use client";

import { useScroll, useTransform, MotionValue } from "framer-motion";
import { useRef } from "react";

/**
 * Retorna um MotionValue de translateY suave conforme o usuário rola a página.
 * Uso: const { ref, y } = useParallax(60); depois <motion.div ref={ref} style={{ y }} />
 */
export function useParallax(distance: number = 60) {
  const ref = useRef<HTMLDivElement | null>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const y: MotionValue<number> = useTransform(scrollYProgress, [0, 1], [-distance, distance]);
  return { ref, y };
}
