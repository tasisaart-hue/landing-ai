export interface Service {
  id: string;
  name: string;
  description: string;
  price?: string;
  duration_minutes: number;
}

export interface Testimonial {
  name: string;
  text: string;
  rating: number; // 1-5
  avatar_url?: string;
}

export interface Client {
  id: string;
  slug: string;
  company_name: string;
  instagram_url: string | null;
  instagram_username: string | null;
  whatsapp: string;
  address: string | null;
  brand_color: string;

  hero_title: string | null;
  hero_subtitle: string | null;
  about_text: string | null;
  cta_text: string;

  gallery_images: string[];
  services: Service[];
  testimonials: Testimonial[];

  latitude: number | null;
  longitude: number | null;
  is_published: boolean;
}

export interface AvailabilitySlot {
  id: string;
  client_id: string;
  weekday: number; // 0 = domingo ... 6 = sábado
  start_time: string; // "09:00"
  end_time: string; // "18:00"
  slot_duration_minutes: number;
  active: boolean;
}

export interface Booking {
  id: string;
  client_id: string;
  service_name: string;
  booking_date: string;
  booking_time: string;
  customer_name: string;
  customer_phone: string;
  status: "pending" | "confirmed" | "cancelled" | "done";
  created_at: string;
}
