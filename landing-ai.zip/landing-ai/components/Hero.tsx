"use client";

import dynamic from "next/dynamic";
import { motion } from "framer-motion";
import { fadeInUp } from "@/lib/animations";
import { useParallax } from "@/lib/useParallax";
import { ArrowDown, MessageCircle } from "lucide-react";

// Three.js só roda no client — carregado sem SSR
const Scene3D = dynamic(() => import("./Scene3D"), { ssr: false });

interface HeroProps {
  title: string;
  subtitle: string;
  ctaText: string;
  whatsappLink: string;
  brandColor?: string;
  backgroundImage?: string;
}

export default function Hero({ title, subtitle, ctaText, whatsappLink, brandColor, backgroundImage }: HeroProps) {
  const { ref, y } = useParallax(50);

  return (
    <section className="relative flex min-h-[100svh] w-full items-center justify-center overflow-hidden bg-surface text-white">
      {/* Fundo com imagem + parallax leve */}
      {backgroundImage && (
        <motion.div ref={ref} style={{ y }} className="absolute inset-0 -z-10">
          <div
            className="h-[120%] w-full bg-cover bg-center opacity-40"
            style={{ backgroundImage: `url(${backgroundImage})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-surface/60 via-surface/70 to-surface" />
        </motion.div>
      )}

      {/* Decoração 3D */}
      <Scene3D color={brandColor} />

      <div className="relative z-10 mx-auto flex max-w-3xl flex-col items-center px-6 text-center">
        <motion.h1
          variants={fadeInUp}
          initial="hidden"
          animate="visible"
          className="font-display text-4xl font-bold leading-tight tracking-tight sm:text-6xl"
        >
          {title}
        </motion.h1>

        <motion.p
          variants={fadeInUp}
          custom={1}
          initial="hidden"
          animate="visible"
          className="mt-6 max-w-xl text-lg text-white/80 sm:text-xl"
        >
          {subtitle}
        </motion.p>

        <motion.a
          variants={fadeInUp}
          custom={2}
          initial="hidden"
          animate="visible"
          href={whatsappLink}
          target="_blank"
          rel="noopener noreferrer"
          whileHover={{ scale: 1.04, translateY: -2 }}
          whileTap={{ scale: 0.97 }}
          className="mt-10 flex items-center gap-2 rounded-full bg-brand px-8 py-4 font-semibold text-white shadow-[0_10px_30px_-10px_var(--brand-color,#6366f1)] transition-shadow hover:shadow-[0_15px_40px_-10px_var(--brand-color,#6366f1)]"
        >
          <MessageCircle size={20} />
          {ctaText}
        </motion.a>
      </div>

      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/50"
      >
        <ArrowDown size={22} />
      </motion.div>
    </section>
  );
}
