"use client";

import { motion } from "framer-motion";
import { MessageCircle } from "lucide-react";

export default function WhatsAppButton({ phone, message }: { phone: string; message?: string }) {
  const digits = phone.replace(/\D/g, "");
  const text = encodeURIComponent(message ?? "Olá! Vim pela sua landing page e gostaria de mais informações.");
  const link = `https://wa.me/${digits}?text=${text}`;

  return (
    <motion.a
      href={link}
      target="_blank"
      rel="noopener noreferrer"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay: 1, type: "spring", stiffness: 200, damping: 15 }}
      whileHover={{ scale: 1.08 }}
      whileTap={{ scale: 0.92 }}
      className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-[0_10px_25px_-8px_rgba(37,211,102,0.7)]"
      aria-label="Falar no WhatsApp"
    >
      <motion.span
        animate={{ scale: [1, 1.4, 1], opacity: [0.6, 0, 0.6] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="absolute inset-0 rounded-full bg-[#25D366]"
      />
      <MessageCircle size={26} className="relative z-10" />
    </motion.a>
  );
}
