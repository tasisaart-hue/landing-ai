"use client";

import { Canvas, useFrame } from "@react-three/fiber";
import { Float, MeshDistortMaterial, Sphere, RoundedBox } from "@react-three/drei";
import { useRef } from "react";
import * as THREE from "three";

/**
 * Elementos 3D puramente decorativos para o Hero.
 * Leve (poucos objetos, sem sombras pesadas) para não pesar no mobile.
 */
function FloatingShapes({ color = "#6366f1" }: { color?: string }) {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.getElapsedTime() * 0.05;
    }
  });

  return (
    <group ref={groupRef}>
      <Float speed={1.4} rotationIntensity={0.6} floatIntensity={1.2}>
        <Sphere args={[1, 48, 48]} position={[-2.4, 0.6, 0]}>
          <MeshDistortMaterial color={color} distort={0.35} speed={1.5} roughness={0.2} metalness={0.3} />
        </Sphere>
      </Float>

      <Float speed={1.1} rotationIntensity={0.8} floatIntensity={1.6}>
        <RoundedBox args={[1.2, 1.2, 1.2]} radius={0.15} position={[2.6, -0.4, -1]}>
          <meshStandardMaterial color="#f472b6" roughness={0.25} metalness={0.4} />
        </RoundedBox>
      </Float>

      <Float speed={1.8} rotationIntensity={0.4} floatIntensity={0.9}>
        <Sphere args={[0.55, 32, 32]} position={[1.2, 1.6, -0.5]}>
          <meshStandardMaterial color="#22d3ee" roughness={0.15} metalness={0.5} />
        </Sphere>
      </Float>
    </group>
  );
}

export default function Scene3D({ color }: { color?: string }) {
  return (
    <div className="pointer-events-none absolute inset-0 -z-0 opacity-90">
      <Canvas camera={{ position: [0, 0, 6], fov: 45 }} dpr={[1, 1.5]} gl={{ antialias: true, alpha: true }}>
        <ambientLight intensity={0.7} />
        <directionalLight position={[3, 4, 5]} intensity={1.1} />
        <FloatingShapes color={color} />
      </Canvas>
    </div>
  );
}
