"use client";

import { motion } from "framer-motion";
import { fadeInUp, staggerContainer, revealOnScroll } from "@/lib/animations";
import { Service } from "@/lib/types";
import { Sparkles } from "lucide-react";

export default function Services({ services }: { services: Service[] }) {
  if (!services?.length) return null;

  return (
    <section id="servicos" className="bg-surface-alt px-6 py-24 text-white">
      <div className="mx-auto max-w-6xl">
        <motion.h2
          {...revealOnScroll}
          variants={fadeInUp}
          className="mb-14 text-center font-display text-3xl font-bold sm:text-4xl"
        >
          Nossos serviços
        </motion.h2>

        <motion.div
          {...revealOnScroll}
          variants={staggerContainer}
          className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3"
        >
          {services.map((service, i) => (
            <motion.div
              key={service.id ?? i}
              variants={fadeInUp}
              custom={i}
              whileHover={{ y: -8, rotateX: 2, rotateY: -2 }}
              style={{ transformStyle: "preserve-3d", perspective: 800 }}
              className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/5 p-6 shadow-xl backdrop-blur-sm transition-shadow duration-300 hover:shadow-[0_20px_50px_-15px_rgba(0,0,0,0.5)]"
            >
              <div className="mb-4 inline-flex rounded-xl bg-brand/20 p-3 text-brand">
                <Sparkles size={22} />
              </div>
              <h3 className="text-lg font-semibold">{service.name}</h3>
              <p className="mt-2 text-sm text-white/70">{service.description}</p>
              <div className="mt-4 flex items-center justify-between text-sm text-white/60">
                {service.price && <span className="font-semibold text-white">{service.price}</span>}
                {service.duration_minutes && <span>{service.duration_minutes} min</span>}
              </div>
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-brand/10 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
