"use client";

import { motion } from "framer-motion";
import { fadeInUp, revealOnScroll } from "@/lib/animations";

export default function About({ companyName, text, image }: { companyName: string; text: string; image?: string }) {
  return (
    <section id="sobre" className="bg-surface px-6 py-24 text-white">
      <div className="mx-auto grid max-w-6xl items-center gap-12 md:grid-cols-2">
        {image && (
          <motion.div
            {...revealOnScroll}
            variants={fadeInUp}
            className="relative aspect-[4/5] overflow-hidden rounded-3xl"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={image} alt={companyName} className="h-full w-full object-cover" />
          </motion.div>
        )}

        <motion.div {...revealOnScroll} variants={fadeInUp} custom={1}>
          <span className="text-sm font-semibold uppercase tracking-widest text-brand">Sobre nós</span>
          <h2 className="mt-3 font-display text-3xl font-bold sm:text-4xl">{companyName}</h2>
          <p className="mt-6 whitespace-pre-line text-white/75">{text}</p>
        </motion.div>
      </div>
    </section>
  );
}
