export default function Footer({ companyName }: { companyName: string }) {
  return (
    <footer className="border-t border-white/10 bg-surface px-6 py-10 text-center text-sm text-white/50">
      <p>
        © {new Date().getFullYear()} {companyName}. Todos os direitos reservados.
      </p>
      <p className="mt-1">
        Site gerado com{" "}
        <span className="font-semibold text-white/70">Landing AI</span>
      </p>
    </footer>
  );
}
