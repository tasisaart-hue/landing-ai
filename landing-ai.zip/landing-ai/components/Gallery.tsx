"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import { zoomIn, revealOnScroll } from "@/lib/animations";

export default function Gallery({ images }: { images: string[] }) {
  if (!images?.length) return null;

  return (
    <section id="galeria" className="bg-surface px-6 py-24 text-white">
      <div className="mx-auto max-w-6xl">
        <motion.h2
          {...revealOnScroll}
          variants={zoomIn}
          className="mb-12 text-center font-display text-3xl font-bold sm:text-4xl"
        >
          Nosso trabalho
        </motion.h2>

        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:gap-6">
          {images.map((src, i) => (
            <motion.div
              key={src + i}
              {...revealOnScroll}
              variants={zoomIn}
              custom={i}
              className="group relative aspect-square overflow-hidden rounded-2xl bg-surface-alt"
            >
              <Image
                src={src}
                alt={`Foto ${i + 1} do Instagram`}
                fill
                sizes="(max-width: 768px) 50vw, 33vw"
                className="object-cover transition-transform duration-700 ease-out group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
