"use client";

import { motion } from "framer-motion";
import { slideInLeft, staggerContainer, revealOnScroll } from "@/lib/animations";
import { Testimonial } from "@/lib/types";
import { Star } from "lucide-react";

export default function Testimonials({ testimonials }: { testimonials: Testimonial[] }) {
  if (!testimonials?.length) return null;

  return (
    <section id="depoimentos" className="bg-surface-alt px-6 py-24 text-white">
      <div className="mx-auto max-w-6xl">
        <motion.h2
          {...revealOnScroll}
          variants={slideInLeft}
          className="mb-14 text-center font-display text-3xl font-bold sm:text-4xl"
        >
          O que dizem nossos clientes
        </motion.h2>

        <motion.div {...revealOnScroll} variants={staggerContainer} className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.name + i}
              variants={slideInLeft}
              custom={i}
              className="rounded-2xl border border-white/10 bg-white/5 p-6"
            >
              <div className="mb-3 flex gap-1 text-amber-400">
                {Array.from({ length: 5 }).map((_, idx) => (
                  <Star key={idx} size={16} fill={idx < t.rating ? "currentColor" : "none"} />
                ))}
              </div>
              <p className="text-sm text-white/80">&ldquo;{t.text}&rdquo;</p>
              <p className="mt-4 text-sm font-semibold text-white">{t.name}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
