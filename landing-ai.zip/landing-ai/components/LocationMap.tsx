"use client";

import { motion } from "framer-motion";
import { fadeInUp, revealOnScroll } from "@/lib/animations";
import { MapPin } from "lucide-react";

export default function LocationMap({ address }: { address?: string | null }) {
  if (!address) return null;

  const mapSrc = `https://www.google.com/maps?q=${encodeURIComponent(address)}&output=embed`;

  return (
    <section id="localizacao" className="bg-surface px-6 py-24 text-white">
      <div className="mx-auto max-w-6xl">
        <motion.h2
          {...revealOnScroll}
          variants={fadeInUp}
          className="mb-8 flex items-center justify-center gap-2 text-center font-display text-3xl font-bold sm:text-4xl"
        >
          <MapPin className="text-brand" /> Onde estamos
        </motion.h2>

        <motion.p {...revealOnScroll} variants={fadeInUp} custom={1} className="mb-8 text-center text-white/70">
          {address}
        </motion.p>

        <motion.div
          {...revealOnScroll}
          variants={fadeInUp}
          custom={2}
          className="overflow-hidden rounded-2xl border border-white/10"
        >
          <iframe
            title="Localização"
            src={mapSrc}
            width="100%"
            height="420"
            style={{ border: 0 }}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </motion.div>
      </div>
    </section>
  );
}
