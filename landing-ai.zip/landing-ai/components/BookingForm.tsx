"use client";

import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { fadeInUp, revealOnScroll } from "@/lib/animations";
import { Service, AvailabilitySlot } from "@/lib/types";
import { supabase } from "@/lib/supabase";
import { CalendarDays, Clock, CheckCircle2 } from "lucide-react";
import { format, addDays, getDay } from "date-fns";
import { ptBR } from "date-fns/locale";

interface BookingFormProps {
  clientId: string;
  services: Service[];
}

/** Gera os próximos 14 dias como opções de data */
function getNextDays(count = 14) {
  return Array.from({ length: count }, (_, i) => addDays(new Date(), i));
}

/** A partir de um slot de disponibilidade, gera horários pontuais (ex: 09:00, 09:30, 10:00...) */
function expandSlotToTimes(slot: AvailabilitySlot): string[] {
  const [startH, startM] = slot.start_time.split(":").map(Number);
  const [endH, endM] = slot.end_time.split(":").map(Number);
  const start = startH * 60 + startM;
  const end = endH * 60 + endM;
  const step = slot.slot_duration_minutes || 30;

  const times: string[] = [];
  for (let m = start; m + step <= end; m += step) {
    const h = Math.floor(m / 60)
      .toString()
      .padStart(2, "0");
    const min = (m % 60).toString().padStart(2, "0");
    times.push(`${h}:${min}`);
  }
  return times;
}

export default function BookingForm({ clientId, services }: BookingFormProps) {
  const [selectedService, setSelectedService] = useState<string>("");
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string>("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");

  const [availableTimes, setAvailableTimes] = useState<string[]>([]);
  const [loadingTimes, setLoadingTimes] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const nextDays = useMemo(() => getNextDays(), []);

  // Busca horários disponíveis sempre que a data muda
  useEffect(() => {
    if (!selectedDate) return;

    async function loadTimes() {
      setLoadingTimes(true);
      setSelectedTime("");

      const weekday = getDay(selectedDate!);

      const { data: slots } = await supabase
        .from("availability_slots")
        .select("*")
        .eq("client_id", clientId)
        .eq("weekday", weekday)
        .eq("active", true);

      const { data: blocked } = await supabase
        .from("blocked_dates")
        .select("date")
        .eq("client_id", clientId)
        .eq("date", format(selectedDate!, "yyyy-MM-dd"));

      if (blocked && blocked.length > 0) {
        setAvailableTimes([]);
        setLoadingTimes(false);
        return;
      }

      const allTimes = (slots ?? []).flatMap((s) => expandSlotToTimes(s as AvailabilitySlot));

      const { data: existingBookings } = await supabase
        .from("bookings")
        .select("booking_time")
        .eq("client_id", clientId)
        .eq("booking_date", format(selectedDate!, "yyyy-MM-dd"))
        .in("status", ["pending", "confirmed"]);

      const takenTimes = new Set((existingBookings ?? []).map((b) => b.booking_time.slice(0, 5)));
      setAvailableTimes(allTimes.filter((t) => !takenTimes.has(t)));
      setLoadingTimes(false);
    }

    loadTimes();
  }, [selectedDate, clientId]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!selectedService || !selectedDate || !selectedTime || !name || !phone) {
      setError("Preencha todos os campos para continuar.");
      return;
    }

    setSubmitting(true);

    const res = await fetch("/api/bookings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        client_id: clientId,
        service_name: selectedService,
        booking_date: format(selectedDate, "yyyy-MM-dd"),
        booking_time: selectedTime,
        customer_name: name,
        customer_phone: phone,
      }),
    });

    setSubmitting(false);

    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      setError(body?.error ?? "Não foi possível concluir o agendamento. Tente outro horário.");
      return;
    }

    setSuccess(true);
  }

  if (success) {
    return (
      <section id="agendar" className="bg-surface-alt px-6 py-24 text-white">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mx-auto flex max-w-md flex-col items-center rounded-2xl border border-white/10 bg-white/5 p-10 text-center"
        >
          <CheckCircle2 size={48} className="mb-4 text-emerald-400" />
          <h3 className="text-xl font-semibold">Agendamento confirmado!</h3>
          <p className="mt-2 text-white/70">Em breve entraremos em contato para confirmar os detalhes.</p>
        </motion.div>
      </section>
    );
  }

  return (
    <section id="agendar" className="bg-surface-alt px-6 py-24 text-white">
      <div className="mx-auto max-w-2xl">
        <motion.h2
          {...revealOnScroll}
          variants={fadeInUp}
          className="mb-10 text-center font-display text-3xl font-bold sm:text-4xl"
        >
          Agende seu horário
        </motion.h2>

        <motion.form
          {...revealOnScroll}
          variants={fadeInUp}
          custom={1}
          onSubmit={handleSubmit}
          className="space-y-6 rounded-2xl border border-white/10 bg-white/5 p-6 sm:p-8"
        >
          {/* Serviço */}
          <div>
            <label className="mb-2 block text-sm font-medium text-white/80">Serviço</label>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {services.map((s) => (
                <button
                  type="button"
                  key={s.id}
                  onClick={() => setSelectedService(s.name)}
                  className={`rounded-xl border px-4 py-3 text-left text-sm transition ${
                    selectedService === s.name
                      ? "border-brand bg-brand/20 text-white"
                      : "border-white/10 bg-transparent text-white/70 hover:border-white/30"
                  }`}
                >
                  {s.name}
                </button>
              ))}
            </div>
          </div>

          {/* Data */}
          <div>
            <label className="mb-2 flex items-center gap-2 text-sm font-medium text-white/80">
              <CalendarDays size={16} /> Data
            </label>
            <div className="flex gap-2 overflow-x-auto pb-2">
              {nextDays.map((d) => {
                const isSelected = selectedDate?.toDateString() === d.toDateString();
                return (
                  <button
                    type="button"
                    key={d.toISOString()}
                    onClick={() => setSelectedDate(d)}
                    className={`flex min-w-[64px] flex-col items-center rounded-xl border px-3 py-2 text-xs transition ${
                      isSelected
                        ? "border-brand bg-brand/20 text-white"
                        : "border-white/10 text-white/70 hover:border-white/30"
                    }`}
                  >
                    <span className="capitalize">{format(d, "EEE", { locale: ptBR })}</span>
                    <span className="text-base font-semibold">{format(d, "dd")}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Horário */}
          <AnimatePresence>
            {selectedDate && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}>
                <label className="mb-2 flex items-center gap-2 text-sm font-medium text-white/80">
                  <Clock size={16} /> Horário
                </label>
                {loadingTimes ? (
                  <p className="text-sm text-white/50">Carregando horários...</p>
                ) : availableTimes.length === 0 ? (
                  <p className="text-sm text-white/50">Nenhum horário disponível nesta data.</p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {availableTimes.map((t) => (
                      <button
                        type="button"
                        key={t}
                        onClick={() => setSelectedTime(t)}
                        className={`rounded-lg border px-3 py-2 text-sm transition ${
                          selectedTime === t
                            ? "border-brand bg-brand/20 text-white"
                            : "border-white/10 text-white/70 hover:border-white/30"
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Dados do cliente */}
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-2 block text-sm font-medium text-white/80">Nome</label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-surface px-4 py-3 text-sm text-white placeholder-white/30 outline-none focus:border-brand"
                placeholder="Seu nome"
              />
            </div>
            <div>
              <label className="mb-2 block text-sm font-medium text-white/80">Telefone</label>
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-surface px-4 py-3 text-sm text-white placeholder-white/30 outline-none focus:border-brand"
                placeholder="(00) 00000-0000"
              />
            </div>
          </div>

          {error && <p className="text-sm text-red-400">{error}</p>}

          <motion.button
            type="submit"
            disabled={submitting}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full rounded-xl bg-brand py-4 font-semibold text-white transition disabled:opacity-50"
          >
            {submitting ? "Agendando..." : "Agendar"}
          </motion.button>
        </motion.form>
      </div>
    </section>
  );
}
