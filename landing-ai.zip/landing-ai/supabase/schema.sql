-- ============================================================
-- LANDING AI — SCHEMA SUPABASE
-- Rode este arquivo no SQL Editor do seu projeto Supabase
-- ============================================================

create extension if not exists "uuid-ossp";

-- ---------- CLIENTES / LANDING PAGES ----------
create table if not exists clients (
  id uuid primary key default uuid_generate_v4(),
  slug text unique not null,               -- usado na URL: /minha-empresa
  company_name text not null,
  instagram_url text,
  instagram_username text,
  instagram_access_token text,             -- token da Graph API (opcional, criptografar em produção)
  whatsapp text not null,
  address text,
  brand_color text default '#6366f1',

  -- conteúdo gerado pela IA (editável no admin)
  hero_title text,
  hero_subtitle text,
  about_text text,
  cta_text text default 'Fale agora no WhatsApp',

  gallery_images jsonb default '[]',       -- array de urls
  services jsonb default '[]',             -- [{ id, name, description, price, duration_minutes }]
  testimonials jsonb default '[]',         -- [{ name, text, rating, avatar_url }]

  latitude double precision,
  longitude double precision,

  is_published boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- ---------- HORÁRIOS DISPONÍVEIS (configurados pelo admin) ----------
create table if not exists availability_slots (
  id uuid primary key default uuid_generate_v4(),
  client_id uuid references clients(id) on delete cascade,
  weekday int not null check (weekday between 0 and 6), -- 0 = domingo
  start_time time not null,
  end_time time not null,
  slot_duration_minutes int default 30,
  active boolean default true,
  created_at timestamptz default now()
);

-- ---------- BLOQUEIOS DE DATA (feriados, folgas) ----------
create table if not exists blocked_dates (
  id uuid primary key default uuid_generate_v4(),
  client_id uuid references clients(id) on delete cascade,
  date date not null,
  reason text
);

-- ---------- AGENDAMENTOS ----------
create table if not exists bookings (
  id uuid primary key default uuid_generate_v4(),
  client_id uuid references clients(id) on delete cascade,
  service_name text not null,
  booking_date date not null,
  booking_time time not null,
  customer_name text not null,
  customer_phone text not null,
  status text default 'pending' check (status in ('pending','confirmed','cancelled','done')),
  created_at timestamptz default now()
);

-- ---------- ADMINS (autenticação simples via Supabase Auth) ----------
create table if not exists admin_users (
  id uuid primary key references auth.users(id) on delete cascade,
  client_id uuid references clients(id) on delete cascade,
  full_name text,
  created_at timestamptz default now()
);

-- índice para evitar duplo agendamento no mesmo horário
create unique index if not exists uniq_booking_slot
  on bookings (client_id, booking_date, booking_time)
  where status in ('pending','confirmed');

-- ---------- RLS ----------
alter table clients enable row level security;
alter table availability_slots enable row level security;
alter table blocked_dates enable row level security;
alter table bookings enable row level security;
alter table admin_users enable row level security;

-- leitura pública de landing pages publicadas
create policy "public read published clients"
  on clients for select
  using (is_published = true);

create policy "public read availability"
  on availability_slots for select
  using (active = true);

create policy "public read blocked dates"
  on blocked_dates for select
  using (true);

-- qualquer visitante pode criar um agendamento
create policy "public insert bookings"
  on bookings for insert
  with check (true);

-- admin (dono do client_id) tem acesso total ao seu próprio client
create policy "admin full access clients"
  on clients for all
  using (
    id in (select client_id from admin_users where admin_users.id = auth.uid())
  );

create policy "admin full access availability"
  on availability_slots for all
  using (
    client_id in (select client_id from admin_users where admin_users.id = auth.uid())
  );

create policy "admin full access bookings"
  on bookings for all
  using (
    client_id in (select client_id from admin_users where admin_users.id = auth.uid())
  );

create policy "admin full access blocked_dates"
  on blocked_dates for all
  using (
    client_id in (select client_id from admin_users where admin_users.id = auth.uid())
  );
